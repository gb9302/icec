# IceC Lab Next - Docker Foundation v0.1

Questa release porta IceC Lab v0.8.3 dentro Docker e prepara PostgreSQL senza cambiare ancora la persistenza dell'app: la UI continua temporaneamente a usare localStorage. Il database viene creato per la migrazione successiva.

## Avvio

1. Copia `.env.example` in `.env`:
   `cp .env.example .env`
2. Modifica almeno `POSTGRES_PASSWORD` se desiderato.
3. Avvia:
   `docker compose up -d --build`
4. Controlla:
   `docker compose ps`
5. Apri `http://localhost:3000`

## Log
`docker compose logs -f`

## Stop
`docker compose down`

NON usare `docker compose down -v` se vuoi conservare il database PostgreSQL: `-v` elimina il volume dati.

## Database
PostgreSQL è disponibile localmente sulla porta 5432. Le tabelle iniziali sono: app_users, ingredients, recipes, recipe_notes, product_profiles.

## Importante
In questa foundation la UI è volutamente la v0.8.3 stabile e usa ancora localStorage. Il prossimo step è aggiungere API/server e migrare i dati nel database senza perdita.
